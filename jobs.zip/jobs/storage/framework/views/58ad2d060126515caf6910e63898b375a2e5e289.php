<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <title>Insert JObs</title>
    <style>
        body{
            margin:0%;
            display: block;
        }
        .navbar{
            display:inline-block;
            width: 100%;
            padding-top:1%;
            box-shadow: 0px 4px 5px -2px rgba(0,0,0,0.75);
        }
        .logo{
            position:absolute;
            padding-left: 3%;
        }
        .head{
            float:right;
        }
        .head>a{
            text-decoration:none;
            padding: 13px;
            float:left;
            font-size: 15px;
            font-family: arial;
            color: black;
        }
        #formdata{
            margin: auto;
            margin-top: 3%;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 20px;
            width: 40%;
            height: 780px;
            margin-bottom: 3%;
        }
        #font{
            font-size: 16px;
        }
        #button{
            padding-left: 15px;
            padding-right: 15px;
            padding-top: 7px;
            padding-bottom: 7px;
            border-radius: 10px;
            margin-right: 2%;
        }
    </style>
</head>
<body>  
    <div class="header">
        <div class="navbar">
            <div class="logo">
                <img src="<?php echo e(asset('img/webkullogo.png')); ?>" alt="logo" height="35px" width="180px">
            </div>
            <div class="head">
                <a href="#">About</a>
                <a href="#">Services</a>
                <a href="#">Technologies</a>
                <a href="#">Careers</a>
                <a href="/">Jobs</a>
            </div>
        </div>
    </div>

    <form id="formdata" action="insertjobs" method="POST">
    <?php echo e(csrf_field()); ?>

		<label for="title" id="font">Title</label>
		<input type="text" name="title" class="form-control" id="title" required><br><br>
		<label for="description" id="font">Description</label>
        <input type="text" name="description" class="form-control" id="description" required><br><br>
        <label for="skills" id="font">Skills</label>
        <input type="text" name="skills" class="form-control" id="skills" required><br><br>
        <label for="ctc" id="font">CTC</label>
        <input type="text" name="ctc" class="form-control" id="ctc" required><br><br>
        <label for="openings" id="font">Openings</label>
        <input type="text" name="openings" class="form-control" id="openings" required><br><br>
        <label for="experience" id="font">Experience</label>
        <input type="text" name="experience" class="form-control" id="experience" required><br><br>
        <label for="interviewprocess" id="font">Interview Process</label>
        <input type="text" name="interviewprocess" class="form-control" id="interviewprocess" required><br><br>   
		<input type="submit" id="button" name="submit" value="Add Jobs">
    </form>
</body>
</html><?php /**PATH E:\xampp\htdocs\jobs\resources\views/addjobs.blade.php ENDPATH**/ ?>