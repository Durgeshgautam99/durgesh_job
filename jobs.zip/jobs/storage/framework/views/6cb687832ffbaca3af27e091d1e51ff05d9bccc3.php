<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Webkul Jobs</title>
    <style>
        body{
            margin:0%;
        }
        .navbar{
            display:inline-block;
            width: 100%;
            padding-top:1%;
            box-shadow: 0px 4px 5px -2px rgba(0,0,0,0.75);
        }
        .logo{
            position:absolute;
            padding-left: 3%;
        }
        .head{
            float:right;
        }
        .head>a{
            text-decoration:none;
            padding: 15px;
            float:left;
            font-family: arial;
            color: black;
        }
        #insertdata{
            float:right;
            padding-left: 15px;
            padding-right: 15px;
            padding-top: 7px;
            border: 1px solid #ccc;
            padding-bottom: 7px;
            border-radius: 10px;
            margin-right: 2%;
            margin-top: 1%;
            color: blue;
            cursor: pointer;
            background-color: #ccc;
            text-decoration: none;
        }
        #showdata{
            padding-left: 15px;
            padding-right: 15px;
            padding-top: 7px;
            border: 1px solid #ccc;
            padding-bottom: 7px;
            border-radius: 10px;
            margin: 30px;
            margin-top: 1%;
            position: absolute;
            color: blue;
            cursor: pointer;
            background-color: #ccc;
            text-decoration: none;
        }
        .section>h1{
            text-align: center;
            font-size: 45px;
            font-family: arial;
            margin-top: 5%;
        }
        #form>p{
            font-size: 30px;
            font-family: arial;
        }
        #form{
            margin: auto;
            width: 70%;
        }
        .button{
            float: left;
            border : 1px solid #ccc;
            font-size: 18px;
            font-family: arial;
            padding-top: 1%;
            padding-bottom: 1%;
            padding-left: 5%;
            padding-right: 5%; 
            margin-right: 3%;
            margin-bottom: 3%;
            text-decoration: none;
            color: blue;
            background-color: #ccc;
            display: inline-block;
        }
        /* .column>a {
            position: relative;
        }
        .column>a:after {
            content: '';
            position: absolute;
            width: 6px;
            height: 6px;
            border: 2px solid;
            border-color: #979492;
            -ms-transform: rotate(45deg);
            -webkit-transform: rotate(45deg);
            transform: rotate(45deg);
            border-left: 0;
            border-bottom: 0;
            margin-top: 5px;
            margin-left: 5px;
            } */
    </style>
</head>
<body>
    <div class="header">
        <div class="navbar">
            <div class="logo">
                <img src="<?php echo e(asset('img/webkullogo.png')); ?>" alt="logo" height="35px" width="180px">
            </div>
            <div class="head">
                <a href="">About</a>
                <a href="">Services</a>
                <a href="">Technologies</a>
                <a href="">Careers</a>
                <a href="">Blog</a>
            </div>
        </div>
    </div>
    <a href="addjobs" id="insertdata">Add Jobs</a>
    <a href="showdata" id="showdata">Show Jobs</a>
    <div class="section">
        <h1>Open Positions</h1>
        <form id="form">
            <p>Engineering</p>   
                <div class="row">
					<div class="column">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="datashow/<?php echo e($value->id); ?>" class="button">
                    <p><?php echo e($value->title); ?></i></p></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
            </div>
        </form>
    </div>
    </div>
</body>
</html><?php /**PATH E:\xampp\htdocs\jobs\resources\views/home.blade.php ENDPATH**/ ?>