<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Show</title>
    <style>
        body{
            margin:0%;
        }
        .navbar{
            display:inline-block;
            width: 100%;
            padding-top:1%;
            box-shadow: 0px 4px 5px -2px rgba(0,0,0,0.75);
        }
        .logo{
            position:absolute;
            padding-left: 3%;
        }
        .head{
            float:right;
        }
        .head>a{
            text-decoration:none;
            padding: 15px;
            float:left;
            font-family: arial;
            color: black;
        }
        form{
            margin-left: 5%;
            margin-top: 3%;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 20px;
            width: 60%;
            height: 400px;
            margin-bottom: 3%;
        }
        .row{
            margin-top: 3%; 
        }
        .column{
    		width: 25%;
    		text-align: center;
    		float: left;
    		margin-right: 7.5%;	
    	}
        #fontsize{
            font-size: 18px;
            font-weight: bold;
            font-family: arial; 
        }
        .add{
            display: inline;
        }
        #changeline{
            display:inline;
            font-family: arial;
        }
        #btn-style{
            padding-left: 15px;
            padding-right: 15px;
            padding-top: 7px;
            padding-bottom: 7px;
            border-radius: px;
            border: 1px solid black;
            width: 40%;
            background-color: #ccc;
        }
        .btn{
            padding-left: 15px;
            padding-right: 15px;
            padding-top: 7px;
            padding-bottom: 7px;
            border-radius: 10px;
            font-size: 15px;
            font-weight: bold;
            color:#ffffff;
            border: 1px solid blue;
            background-color: blue;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="navbar">
            <div class="logo">
                <img src="<?php echo e(asset('img/webkullogo.png')); ?>" alt="logo" height="35px" width="180px">
            </div>
            <div class="head">
                <a href="">About</a>
                <a href="">Services</a>
                <a href="">Technologies</a>
                <a href="">Careers</a>
                <a href="">Blog</a>
            </div>
        </div>
    </div>

    <form action="../applyjob">
    <h1 style="font-family: arial;"><?php echo e($data->title); ?></h1>
    <p style="font-family: arial;"><?php echo e($data->description); ?></p>
    <p id="fontsize" class="add">Skills :</p>
    <p id="changeline"><?php echo e($data->skills); ?></p>
    <div class="row">
		<div class="column">
            <p id="fontsize">Experience</p>
            <p style="font-size: 20px;"><?php echo e($data->experience); ?></p>
        </div>
        <div class="column">
            <p id="fontsize">Openings</p>
            <p style="font-size: 20px;"><?php echo e($data->openings); ?></p>
        </div>
        <div class="column">
            <p id="fontsize">CTC</p>
            <p style="font-size: 20px;"><?php echo e($data->ctc); ?></p>
        </div>
        <p id="fontsize">Interview Process</p>
        <p id="btn-style"><?php echo e($data->interviewprocess); ?></p>
    </div>
    <input type="submit" class="btn" value="Apply Job">
</form>

</body>
</html><?php /**PATH E:\xampp\htdocs\jobs\resources\views/datashow.blade.php ENDPATH**/ ?>