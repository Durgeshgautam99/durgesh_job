<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <title>Apply Job</title>
    <style>
         body{
            margin:0%;
        }
        .navbar{
            display:inline-block;
            width: 100%;
            padding-top:1%;
            box-shadow: 0px 4px 5px -2px rgba(0,0,0,0.75);
        }
        .logo{
            position:absolute;
            padding-left: 3%;
        }
        .head{
            float:right;
        }
        .head>a{
            text-decoration:none;
            padding: 15px;
            float:left;
            font-family: arial;
            color: black;
        }
        form{
            margin: auto;
            margin-top: 3%;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 20px;
            width: 40%;
            height: 565px;
            margin-bottom: 3%;
        }
        p{
            font-weight: bold;
            font-size: 16px;
            text-align: center;
        }
    </style>
</head>
<body>
<div class="header">
        <div class="navbar">
            <div class="logo">
                <img src="{{asset('img/webkullogo.png')}}" alt="logo" height="35px" width="180px">
            </div>
            <div class="head">
                <a href="">About</a>
                <a href="">Services</a>
                <a href="">Technologies</a>
                <a href="">Careers</a>
                <a href="">Blog</a>
            </div>
        </div>
    </div>
    <p>JOB APPLICATION FORM</p>
<form id="form" action="insertdata" method="POST">
{{ csrf_field() }}
		<label for="name" id="font">Full Name</label>
		<input type="text" name="name" class="form-control" required><br><br>
		<label for="email" id="font">Email</label>
        <input type="text" name="email" class="form-control" ><br><br>
        <label for="contact" id="font">Contact</label>
        <input type="text" name="contact" class="form-control" ><br><br>
        <label for="currentctc" id="font">Current CTC</label>
        <input type="text" name="currentctc" class="form-control" ><br><br>
        <label for="exceptedctc" id="font">Excepted CTC</label>
        <input type="text" name="exceptedctc" class="form-control" ><br><br>   
		<input type="submit" name="submit" id="button" value="Add Jobs">
    </form>
</body>
</html>