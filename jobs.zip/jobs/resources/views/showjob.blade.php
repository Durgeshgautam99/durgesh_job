<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show Jobs</title>
    <style>
        body{
            margin:0%;
        }
        .navbar{
            display:inline-block;
            width: 100%;
            padding-top:1%;
            box-shadow: 0px 4px 5px -2px rgba(0,0,0,0.75);
        }
        .logo{
            position:absolute;
            padding-left: 3%;
        }
        .head{
            float:right;
        }
        .head>a{
            text-decoration:none;
            padding: 15px;
            float:left;
            font-family: arial;
            color: black;
        }
        table,th,td,tr{
            border: 1px solid black;
        }
        form{
            width: 50%;
            margin: auto;
            margin-top: 2%;
        }
    </style>
</head>
<body>
<div class="header">
        <div class="navbar">
            <div class="logo">
                <img src="{{asset('img/webkullogo.png')}}" alt="logo" height="35px" width="180px">
            </div>
            <div class="head">
                <a href="">About</a>
                <a href="">Services</a>
                <a href="">Technologies</a>
                <a href="">Careers</a>
                <a href="/">Home</a>
            </div>
        </div>
    </div>

    <form action="">
        <table >
            <tr>
                <th>Name</th>
                <th>Email Id</th>
                <th>Contact Number</th>
                <th>Current CTC</th>
                <th>Excepted CTC</th>
            </tr>
            @foreach($data as $k=>$value)
            <tr>
                <td>{{$value->name}}</td>
                <td>{{$value->email}}</td>
                <td>{{$value->contact}}</td>
                <td>{{$value->currentctc}}</td>
                <td>{{$value->exceptedctc}}</td>
            </tr>
            @endforeach
        </table>
    </form>
</body>
</html>