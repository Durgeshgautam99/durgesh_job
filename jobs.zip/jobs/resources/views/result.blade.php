<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Successfully</title>
    <style>
        body{
            margin:0%;
        }
        .navbar{
            display:inline-block;
            width: 100%;
            padding-top:1%;
            box-shadow: 0px 4px 5px -2px rgba(0,0,0,0.75);
        }
        .logo{
            position:absolute;
            padding-left: 3%;
        }
        .head{
            float:right;
        }
        .head>a{
            text-decoration:none;
            padding: 15px;
            float:left;
            font-family: arial;
            color: black;
        }
        form{
            margin: auto;
            margin-top: 3%;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 20px;
            width: 60%;
            height: 300px;
        }
        h1{
            font-family: arial;
        }
        .btn{
            padding-left: 15px;
            padding-right: 15px;
            padding-top: 7px;
            padding-bottom: 7px;
            border-radius: 10px;
            border: 1px solid blue;
            background-color: blue;
            color: #ffffff; 
            margin-right: 2%;
            margin-top: 1%;
            cursor: pointer;
            text-decoration: none;
        }
    </style>
</head>
<body>
<div class="header">
        <div class="navbar">
            <div class="logo">
                <img src="{{asset('img/webkullogo.png')}}" alt="logo" height="35px" width="180px">
            </div>
            <div class="head">
                <a href="">About</a>
                <a href="">Services</a>
                <a href="">Technologies</a>
                <a href="">Careers</a>
                <a href="">Blog</a>
            </div>
        </div>
    </div>
    <form action="">
        <h1>Successfully Apply Job</h1>
        <p>Thanks for a apply</p><br><br>
        <a href="/" class="btn">Go to Home Page</a>
    </form>
</body>
</html>