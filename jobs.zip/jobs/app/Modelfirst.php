<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Modelfirst extends Model
{
    protected $table = "insertjob";
    public $timestamps=false;
}
