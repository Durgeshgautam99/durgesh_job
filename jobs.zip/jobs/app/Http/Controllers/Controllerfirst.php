<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Modelfirst;
use App\Modelsecond;
class Controllerfirst extends Controller
{

    public function fetch(){
        $data = Modelfirst::all();
        return view ("home",compact('data'));
    }

    public function insertjob(Request $request){
        $request->validate([
            'title'        =>          'required',
            'description'  =>          'required',
            'skills'         =>        'required',
            'ctc'        =>            'required',
            'openings'         =>      'required',
            'experience'  =>           'required',
            'interviewprocess'  =>     'required',
            ]);
        $modelfirst = new Modelfirst; 
        $modelfirst->title=$request->title;
        $modelfirst->description=$request->description;
        $modelfirst->skills=$request->skills;
        $modelfirst->ctc=$request->ctc;
        $modelfirst->openings=$request->openings;
        $modelfirst->experience=$request->experience;
        $modelfirst->interviewprocess=$request->interviewprocess;   
            print_r($modelfirst);
         //insert command
            $modelfirst->save();
            return redirect('/');
    }

    public function datashow($id){
        $data = Modelfirst::find($id);
        // echo "<pre>";
        //     print_r($data);
        // echo "</pre>";
        return view('datashow', compact('data'));
    }

    public function insert(Request $request){
        $request->validate([
            'name'        =>          'required',
            'email'  =>          'required',
            'contact'         =>        'required',
            'currentctc'        =>            'required',
            'exceptedctc'         =>      'required',
        ]);
        $data = new Modelsecond; 
        $data->name=$request->name;
        $data->email = $request->email;
        $data->contact = $request->contact;
        $data->currentctc = $request->currentctc;
        $data->exceptedctc = $request->exceptedctc;
            //insert Command
        $data->save();
            return redirect('result');
    }

    public function show(){
        $data = Modelsecond::all();
        return view('showjob', compact('data'));
    }
}
