<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Modelsecond extends Model
{
    protected $table = "applyjobinsert";
    public $timestamps=false;
}
